CREATE TABLE `user` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` mediumint NOT NULL,
  `status` text NOT NULL,
  `profile_image` text NOT NULL,
  `job_title` text NOT NULL,
  `company_name` text NOT NULL,
  `location` text NOT NULL,
  `phone_number` text NOT NULL,
  `dob` text NOT NULL,
  `created_at` timestamp NOT NULL
);

CREATE TABLE `candidates` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` text NOT NULL,
  `location` text,
  `image_url` text,
  `linkedin` varchar(255) NOT NULL,
  `added_at` timestamp NOT NULL,
  `user_id` int,
  `title` varchar(255) NOT NULL,
  `summary` text NOT NULL,
  `skills` text NOT NULL,
  `status` text NOT NULL,
  `education` text NOT NULL
);

CREATE TABLE `jobs` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `requirements` text NOT NULL,
  `location` varchar(255) NOT NULL,
  `salary_range` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL,
  `company_name` varchar(255) NOT NULL,
  `company_website` varchar(255) NOT NULL,
  `employment_type` varchar(255) NOT NULL,
  `industry` varchar(255) NOT NULL,
  `experience_level` varchar(255) NOT NULL,
  `job_function` varchar(255) NOT NULL,
  `job_keywords` varchar(255) NOT NULL,
  `job_post_url` varchar(255) NOT NULL,
  `user_id` int
);

CREATE TABLE `candidate_tags` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `candidate_id` int,
  `tag_name` varchar(255) NOT NULL
);

CREATE TABLE `jobs_match` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `candidate_id` int,
  `job_id` int
);

CREATE TABLE `reminders` (
  `id` int PRIMARY KEY AUTO_INCREMENT,
  `user_id` int,
  `type` varchar(20),
  `reminder_date` date,
  `reminder_time` time,
  `reminder_notes` text,
  `job_id` int,
  `candidate_id` int,
  `created_at` datetime NOT NULL DEFAULT (current_timestamp)
);

ALTER TABLE `candidates` ADD FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

ALTER TABLE `jobs` ADD FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

ALTER TABLE `candidate_tags` ADD FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`);

ALTER TABLE `jobs_match` ADD FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`);

ALTER TABLE `jobs_match` ADD FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`);

ALTER TABLE `reminders` ADD FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

ALTER TABLE `reminders` ADD FOREIGN KEY (`job_id`) REFERENCES `jobs` (`id`);

ALTER TABLE `reminders` ADD FOREIGN KEY (`candidate_id`) REFERENCES `candidates` (`id`);
