const serverUrl = "https://talentpool.webdevxio.com/ats/store.php"; // my server

function appendData(values) {
  const data = {
    name: values[0],
    title: values[1],
    location: values[2],
    image_url: values[3],
    url: values[4],
  };

  fetch(serverUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      console.log("Data:", data);
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "getProfileData") {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      let currentTab = tabs[0];
      let currentTabUrl = currentTab.url;

      chrome.tabs.executeScript(
        {
          code: '({ name: document.querySelector("h1.text-heading-xlarge").textContent.trim(), title: document.querySelector("div.text-body-medium.break-words").textContent.trim(), location: document.querySelector("span.text-body-small.inline.t-black--light.break-words").textContent.trim(), image_url: document.querySelector("img.pv-top-card-profile-picture__image").src })',
        },
        function (result) {
          let profileData = result[0];
          console.log("Profile Data:", profileData);

          if (profileData.name) {
            appendData([
              profileData.name,
              profileData.title,
              profileData.location,
              profileData.image_url,
              currentTabUrl,
            ]);
            sendResponse(profileData);
          } else {
            console.log("Name not found");
            sendResponse("");
          }
        }
      );
    });
    return true;
  }
});
