document.addEventListener("DOMContentLoaded", function () {
  const getProfileDataBtn = document.getElementById("getProfileDataBtn");
  const name = document.getElementById("name");
  const title = document.getElementById("title");
  const location = document.getElementById("location");
  const image = document.getElementById("image_url");

  getProfileDataBtn.addEventListener("click", function () {
    chrome.runtime.sendMessage(
      { action: "getProfileData" },
      function (response) {
        if (response) {
          name.textContent = response.name;
          title.textContent = response.title;
          location.textContent = response.location;
          image.src = response.image_url;
        } else {
          console.log("Profile data not found");
        }
      }
    );
  });
});
