chrome.runtime.sendMessage({ action: "getProfileData" }, function (response) {
  console.log(response);
});
