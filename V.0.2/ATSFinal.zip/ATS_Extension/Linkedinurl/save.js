document.querySelector("h1.text-heading-xlarge").textContent.trim();
document.querySelector("div.text-body-medium.break-words").textContent.trim();

const serverUrl = "https://talentpool.webdevxio.com/ats/store.php"; // replace with your server URL

function appendData(values) {
  const data = {
    name: values[0],
  };

  fetch(serverUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error("Network response was not ok");
      }
      return response.json();
    })
    .then((data) => {
      console.log("Data:", data);
    })
    .catch((error) => {
      console.error("Error:", error);
    });
}

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.action === "getProfileName") {
    chrome.tabs.executeScript(
      {
        code: 'document.querySelector("h1.text-heading-xlarge").textContent.trim()',
      },
      function (result) {
        let name = result[0];
        console.log("Name:", name);
        if (name) {
          appendData([name]);
          sendResponse(name);
        } else {
          console.log("Name not found");
          sendResponse("");
        }
      }
    );
    return true;
  }
});
